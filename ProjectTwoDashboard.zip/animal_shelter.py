from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    #CRUD operations for Animal collection in MongoDB
    
    def __init__(self, username, password):
    #Connection variables
        ##username = 'aac'
        ##password = 'password'
        #HOST = 'nv-desktop-services.apporto.com'
        #PORT = 30133
        #DB = 'AAC'
        #COL = 'animals'

        self.client = MongoClient('mongodb://%s:%s@nv-desktop-services.apporto.com:30133/AAC' % (username, password))
        self.database = self.client['AAC']
        self.collections = self.database['animals']
                
    #Method to implement the C in CRUD
    def create(self, data):
        if data is not None:
            inserted = self.database.animals.insert_one(data)
            if inserted != 0:
                return True
            return False
        else: 
            raise Exception("Nothing to save, parameter is empty")

    #Method to implement the R in CRUD
    def read(self, dataSearch):
        if dataSearch is not None:
            read = self.database.animals.find(dataSearch, {"_id": False})
        else:
            raise Exception("Nothing to read, parameter is empty")
        return read
    
    #Method to implement the U in CRUD
    def update(self, dataSearch, dataUpdate):
        if dataSearch and dataUpdate is not None:
            updated = self.database.animals.update_many(dataSearch, {"$set": dataUpdate})
        else:
            raise Exception("Nothing to update, parameters are empty")
        return updated.modified_count
    
    #Method to implement the R in CRUD
    def delete(self, dataDelete):
        if dataDelete is not None:
            deleted = self.database.animals.delete_many(dataDelete)
        else:
            raise Exception("nothing to delete, parameter is empty")
        return deleted.deleted_count
      